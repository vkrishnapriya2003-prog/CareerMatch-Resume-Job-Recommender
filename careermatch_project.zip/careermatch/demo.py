"""Console demo of the Sprint 1 increment (US1-US3)."""
from careermatch.matcher import Job, recommend
from careermatch.skills import extract_skills

RESUME = """V. Krishnapriya - MCA student.
Skills: Python3, SQL, Flask, HTML5, CSS, NLP projects with spaCy and sklearn,
prompt engineering, GitHub and Docker."""

JOBS = [
    Job("NLP Engineer", ["python", "nlp", "spacy"], ["docker", "git"]),
    Job("Web Developer", ["html", "css", "javascript", "react"], ["git"]),
    Job("Data Analyst", ["python", "sql"], ["machine learning"]),
    Job("Prompt Engineer", ["prompt engineering", "python"], ["nlp"]),
]

if __name__ == "__main__":
    skills = extract_skills(RESUME)
    print("US1 Skills found  :", ", ".join(skills))
    print("US2/US3 Top matches")
    for job, score, gap in recommend(RESUME, JOBS, top_n=3):
        gap_text = ", ".join(gap) if gap else "none"
        print(f"  {job.title:<16} {score:>5}%   skill gap: {gap_text}")
