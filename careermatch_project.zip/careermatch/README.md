# CareerMatch - Agile Release and Sprint Plan (Sprint 1 increment)

Run locally:
    pip install -r requirements.txt
    pytest -v
    python demo.py

Run the plan on GitHub (needs gh CLI and git):
    gh auth login
    gh repo create careermatch --public --clone
    # copy these files into the repo, then
    git add . && git commit -m "Initial CareerMatch plan" && git push -u origin main
    bash scripts/setup_github.sh OWNER/careermatch   # labels, 4 milestones, 10 issues
See Section 7 of the report for the full 10-step flow (branch, PR, CI, merge, release).
