"""CareerMatch - resume analysis and job recommendation (Sprint 1 increment)."""
__version__ = "0.1.0"
