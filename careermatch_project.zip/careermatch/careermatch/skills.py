"""US1 - Resume skill extraction (rule based NLP, no external model needed)."""
import re

# canonical skill -> alternative spellings found in resumes
SKILL_BANK = {
    "python": ["python", "python3"],
    "java": ["java"],
    "sql": ["sql", "mysql", "postgresql", "sqlite"],
    "html": ["html", "html5"],
    "css": ["css", "css3"],
    "javascript": ["javascript", "js", "es6"],
    "react": ["react", "reactjs", "react.js"],
    "flask": ["flask"],
    "fastapi": ["fastapi"],
    "nlp": ["nlp", "natural language processing"],
    "machine learning": ["machine learning", "ml"],
    "scikit-learn": ["scikit-learn", "sklearn"],
    "spacy": ["spacy"],
    "git": ["git", "github"],
    "docker": ["docker"],
    "pytest": ["pytest"],
    "prompt engineering": ["prompt engineering", "prompt design"],
}

_WORD = r"(?<![A-Za-z0-9+#.]){}(?![A-Za-z0-9+#])"


def extract_skills(text):
    """Return the sorted list of canonical skills mentioned in resume text."""
    found = set()
    lowered = text.lower()
    for skill, aliases in SKILL_BANK.items():
        for alias in aliases:
            if re.search(_WORD.format(re.escape(alias)), lowered):
                found.add(skill)
                break
    return sorted(found)
