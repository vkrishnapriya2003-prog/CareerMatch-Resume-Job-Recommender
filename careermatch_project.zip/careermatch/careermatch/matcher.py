"""US2 / US3 - job matching, skill-gap report and ranked recommendations."""
from dataclasses import dataclass, field

from .skills import extract_skills


@dataclass
class Job:
    title: str
    required: list = field(default_factory=list)
    nice_to_have: list = field(default_factory=list)


REQUIRED_WEIGHT = 0.8
BONUS_WEIGHT = 0.2


def match_score(resume_skills, job):
    """Weighted coverage in percent: 80% required skills, 20% nice-to-have."""
    have = set(resume_skills)
    req = set(job.required)
    nice = set(job.nice_to_have)
    req_part = len(have & req) / len(req) if req else 1.0
    nice_part = len(have & nice) / len(nice) if nice else 0.0
    return round((REQUIRED_WEIGHT * req_part + BONUS_WEIGHT * nice_part) * 100, 1)


def skill_gap(resume_skills, job):
    """Required skills the candidate still has to learn (sorted)."""
    return sorted(set(job.required) - set(resume_skills))


def recommend(resume_text, jobs, top_n=3):
    """Return the best top_n jobs as (job, score, gap) sorted by score."""
    skills = extract_skills(resume_text)
    ranked = [(j, match_score(skills, j), skill_gap(skills, j)) for j in jobs]
    ranked.sort(key=lambda r: (-r[1], r[0].title))
    return ranked[:top_n]
