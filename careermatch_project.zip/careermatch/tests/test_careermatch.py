import pytest

from careermatch.matcher import Job, match_score, recommend, skill_gap
from careermatch.skills import extract_skills

RESUME = """Priya - MCA student. Skills: Python3, SQL, Flask, HTML5, CSS,
NLP projects with spaCy and sklearn. Uses GitHub and Docker."""


@pytest.fixture
def jobs():
    return [
        Job("NLP Engineer", ["python", "nlp", "spacy"], ["docker", "git"]),
        Job("Web Developer", ["html", "css", "javascript", "react"], ["git"]),
        Job("Data Analyst", ["python", "sql"], ["machine learning"]),
    ]


# ---- US1 skill extraction -------------------------------------------------
def test_extracts_known_skills():
    skills = extract_skills(RESUME)
    for s in ["python", "sql", "flask", "nlp", "spacy", "docker", "git"]:
        assert s in skills


def test_alias_is_mapped_to_canonical_name():
    assert "scikit-learn" in extract_skills("worked with sklearn")


def test_extraction_is_case_insensitive():
    assert extract_skills("PYTHON and Sql") == ["python", "sql"]


def test_no_partial_word_match():
    # 'java' must not be detected inside 'javascript'
    assert extract_skills("javascript developer") == ["javascript"]


def test_empty_text_gives_no_skills():
    assert extract_skills("") == []


# ---- US2 matching ---------------------------------------------------------
def test_full_required_match_scores_at_least_80(jobs):
    skills = ["python", "nlp", "spacy"]
    assert match_score(skills, jobs[0]) == 80.0


def test_bonus_skills_raise_score_to_100(jobs):
    skills = ["python", "nlp", "spacy", "docker", "git"]
    assert match_score(skills, jobs[0]) == 100.0


def test_no_overlap_scores_zero(jobs):
    assert match_score(["java"], jobs[1]) == 0.0


# ---- US3 skill gap and ranking -------------------------------------------
def test_skill_gap_lists_missing_required_skills(jobs):
    assert skill_gap(["html", "css"], jobs[1]) == ["javascript", "react"]


def test_recommend_returns_best_job_first(jobs):
    top = recommend(RESUME, jobs, top_n=3)
    assert top[0][0].title == "NLP Engineer"
    scores = [r[1] for r in top]
    assert scores == sorted(scores, reverse=True)


def test_recommend_respects_top_n(jobs):
    assert len(recommend(RESUME, jobs, top_n=2)) == 2
