#!/usr/bin/env bash
# Creates labels, milestones (sprints) and issues (user stories) from docs/sprint_plan.csv
# Usage:  gh auth login   (once)   then   bash scripts/setup_github.sh <owner>/<repo>
set -euo pipefail
REPO="${1:?usage: setup_github.sh <owner>/<repo>}"

for n in 1 2 3 4; do
  gh label create "sprint-$n" --color "1D76DB" --repo "$REPO" --force
done
gh label create "user-story" --color "0E8A16" --repo "$REPO" --force

declare -A GOALS=(
  [1]="Resume parsing, matching and skill gap (core engine)"
  [2]="ATS score, job management and filters"
  [3]="Web dashboard and history"
  [4]="Reports, canary release and rollback"
)
declare -A DUE=([1]="2026-11-16" [2]="2026-11-30" [3]="2026-12-14" [4]="2026-12-28")

for n in 1 2 3 4; do
  gh api "repos/$REPO/milestones" -f title="Sprint $n" \
     -f description="${GOALS[$n]}" -f due_on="${DUE[$n]}T18:00:00Z" >/dev/null
done

tail -n +2 docs/sprint_plan.csv | while IFS=, read -r id sprint story points prio label; do
  gh issue create --repo "$REPO" --title "$id: $story" \
     --body "Story points: $points | Priority: $prio" \
     --label "user-story,$label" --milestone "Sprint $sprint"
done
echo "Done: 4 milestones and 10 issues created in $REPO"
